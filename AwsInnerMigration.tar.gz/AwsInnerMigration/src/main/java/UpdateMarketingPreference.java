
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.*;
import com.google.gson.Gson;
import profile.Entries;
import profile.UserProfile;

import java.util.*;

public class UpdateMarketingPreference {

    public static void main(String[] args) {

        Table table = getDynamoDBTable();
        fetchMarketingPreferences(table);
    }

    private static void fetchMarketingPreferences(Table table) {

        Map<String, Object> expressionAttributeValues = new HashMap();
        expressionAttributeValues.put(":true", "true");
        expressionAttributeValues.put(":false", false);

        ItemCollection<ScanOutcome> items = table.scan("profile.responses.vertical.entries[0].marketingPreference.noContactViaEmail = :false OR profile.responses.vertical.entries[0].marketingPreference.noContactViaEmail = :true " +
                        "OR profile.responses.vertical.entries[0].marketingPreference.contactViaEmail = :false OR profile.responses.vertical.entries[0].marketingPreference.contactViaEmail = :true", // FilterExpression
                "username, profile.core, profile.responses.vertical.entries", // ProjectionExpression
                null, // ExpressionAttributeNames - not used in this example
                expressionAttributeValues);

        Iterator<Item> iterator = items.iterator();
        Gson gson = new Gson();

        while (iterator.hasNext()) {

            UserProfile profile = gson.fromJson(iterator.next().toJSONPretty(), UserProfile.class);
            updateProfile(profile);

        }
    }

    private static void updateProfile(UserProfile profile) {

        Iterator<Entries> marketingIterator = profile.getProfile().getResponses().getVertical().getEntries().iterator();
        String country = profile.getProfile().getCore().getCountry();

        while (marketingIterator.hasNext()) {

            Entries marketingEntry = marketingIterator.next();

            if (profile.getUsername().contains("008e12a2-521e-4428-b937-5f45da1d7386")) {


                if (profile.getProfile().getCore().getCountry() != null && marketingEntry.getMarketingPreference().getContactViaEmail() != null
                        && (country.contains("CA") || country.contains("US"))) {
                    System.out.println("======================OPT-IN===============================");
                    System.out.println("contct via email:" + marketingEntry.getMarketingPreference().getContactViaEmail());
                    System.out.println("No contct via email:" + marketingEntry.getMarketingPreference().getNoContactViaEmail());
                    System.out.println("No contct via post:" + marketingEntry.getMarketingPreference().getNoContactViaPost());
                    System.out.println("No contct via tele:" + marketingEntry.getMarketingPreference().getNoContactViaTelephone());
                    System.out.println("@type:" + marketingEntry.getMarketingPreference().getType());
                    marketingEntry.getMarketingPreference().setType("opt-in");

                    System.out.println("Country: " + profile.getProfile().getCore().getCountry());
                    System.out.println("update Type: " + marketingEntry.getMarketingPreference().getType());
                }
                if (profile.getProfile().getCore().getCountry() != null && marketingEntry.getMarketingPreference().getNoContactViaEmail() != null && (!country.contains("CA") && !country.contains("US"))) {

                    System.out.println("======================OPT-Out===============================");
                    System.out.println("contct via email:" + marketingEntry.getMarketingPreference().getContactViaEmail());
                    System.out.println("No contct via email:" + marketingEntry.getMarketingPreference().getNoContactViaEmail());
                    System.out.println("No contct via post:" + marketingEntry.getMarketingPreference().getNoContactViaPost());
                    System.out.println("No contct via tele:" + marketingEntry.getMarketingPreference().getNoContactViaTelephone());
                    System.out.println("@type:" + marketingEntry.getMarketingPreference().getType());
                    marketingEntry.getMarketingPreference().setType("opt-out");

                    System.out.println("Country: " + profile.getProfile().getCore().getCountry());
                    System.out.println("update Type: " + marketingEntry.getMarketingPreference().getType());
                }

            }
        }

    }

    private static Table getDynamoDBTable() {

        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(AwsCredentials.getAws_access_key_id(),
                AwsCredentials.getAws_secret_key());

        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .withRegion("eu-west-1")
                .build();
        DynamoDB dynamoDB = new DynamoDB(client);
        String tableName = "ias-profile-core-qa";

        Table table = dynamoDB.getTable(tableName);
        return table;
    }
}
