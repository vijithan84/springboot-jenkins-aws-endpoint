package profile;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "acceptTerms",
        "addressLine1",
        "addressLine2",
        "city",
        "companyName",
        "companySize",
        "country",
        "email",
        "forename",
        "id",
        "industry",
        "jobFunction",
        "jobTitle",
        "marketingPreferences",
        "otherJobFunction",
        "phoneNumber",
        "photo",
        "postcode",
        "state",
        "surname"
})
public class Core {

    @JsonProperty("acceptTerms")
    private Boolean acceptTerms;
    @JsonProperty("addressLine1")
    private String addressLine1;
    @JsonProperty("addressLine2")
    private String addressLine2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("companyName")
    private String companyName;
    @JsonProperty("companySize")
    private String companySize;
    @JsonProperty("country")
    private String country;
    @JsonProperty("email")
    private String email;
    @JsonProperty("forename")
    private String forename;
    @JsonProperty("id")
    private String id;
    @JsonProperty("industry")
    private String industry;
    @JsonProperty("jobFunction")
    private String jobFunction;
    @JsonProperty("jobTitle")
    private String jobTitle;
    @JsonProperty("marketingPreferences")
    private Object marketingPreferences;
    @JsonProperty("otherJobFunction")
    private Object otherJobFunction;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("photo")
    private Object photo;
    @JsonProperty("postcode")
    private String postcode;
    @JsonProperty("state")
    private Object state;
    @JsonProperty("surname")
    private String surname;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("acceptTerms")
    public Boolean getAcceptTerms() {
        return acceptTerms;
    }

    @JsonProperty("acceptTerms")
    public void setAcceptTerms(Boolean acceptTerms) {
        this.acceptTerms = acceptTerms;
    }

    @JsonProperty("addressLine1")
    public String getAddressLine1() {
        return addressLine1;
    }

    @JsonProperty("addressLine1")
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    @JsonProperty("addressLine2")
    public String getAddressLine2() {
        return addressLine2;
    }

    @JsonProperty("addressLine2")
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("companyName")
    public String getCompanyName() {
        return companyName;
    }

    @JsonProperty("companyName")
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @JsonProperty("companySize")
    public String getCompanySize() {
        return companySize;
    }

    @JsonProperty("companySize")
    public void setCompanySize(String companySize) {
        this.companySize = companySize;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("forename")
    public String getForename() {
        return forename;
    }

    @JsonProperty("forename")
    public void setForename(String forename) {
        this.forename = forename;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("industry")
    public String getIndustry() {
        return industry;
    }

    @JsonProperty("industry")
    public void setIndustry(String industry) {
        this.industry = industry;
    }

    @JsonProperty("jobFunction")
    public String getJobFunction() {
        return jobFunction;
    }

    @JsonProperty("jobFunction")
    public void setJobFunction(String jobFunction) {
        this.jobFunction = jobFunction;
    }

    @JsonProperty("jobTitle")
    public String getJobTitle() {
        return jobTitle;
    }

    @JsonProperty("jobTitle")
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    @JsonProperty("marketingPreferences")
    public Object getMarketingPreferences() {
        return marketingPreferences;
    }

    @JsonProperty("marketingPreferences")
    public void setMarketingPreferences(Object marketingPreferences) {
        this.marketingPreferences = marketingPreferences;
    }

    @JsonProperty("otherJobFunction")
    public Object getOtherJobFunction() {
        return otherJobFunction;
    }

    @JsonProperty("otherJobFunction")
    public void setOtherJobFunction(Object otherJobFunction) {
        this.otherJobFunction = otherJobFunction;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("photo")
    public Object getPhoto() {
        return photo;
    }

    @JsonProperty("photo")
    public void setPhoto(Object photo) {
        this.photo = photo;
    }

    @JsonProperty("postcode")
    public String getPostcode() {
        return postcode;
    }

    @JsonProperty("postcode")
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    @JsonProperty("state")
    public Object getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(Object state) {
        this.state = state;
    }

    @JsonProperty("surname")
    public String getSurname() {
        return surname;
    }

    @JsonProperty("surname")
    public void setSurname(String surname) {
        this.surname = surname;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}