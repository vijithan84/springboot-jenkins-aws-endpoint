public class AwsCredentials {
    private static final String aws_access_key_id = "AKIAJG7QQYQUBNOUEW3Q";
    private static final String aws_secret_key = "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";

    public static String getAws_access_key_id() {
        return aws_access_key_id;
    }

    public static String getAws_secret_key() {
        return aws_secret_key;
    }
}
