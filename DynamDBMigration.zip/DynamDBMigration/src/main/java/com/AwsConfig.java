package com;

public class AwsConfig {


    public static final String AWS_ACCESS_KEY = "your acc key";
    public static final String AWS_SECRET_KEY = "your sec key";
    public static final String AWS_REGION = "us-east-2";
    public static final String TABLE_NAME = "profile";


}
