package com;
public class DynamoDBMigration {


    public static void main(String args[]) {

    }
}
