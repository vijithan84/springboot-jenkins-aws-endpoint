package com.entity;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.*;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DBMigration {
    public AmazonDynamoDB getDynamoDbInstance() {

        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(
                "111AKIAJG7QQYQUBNOUEW3Q",
                "111uWejXyQHT8Dk2pXamb/xY3FLvme/bxVIxsAkj95G");


        AmazonDynamoDB dynamoDB = AmazonDynamoDBClientBuilder.standard()
                //.withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .withRegion("eu-west-2")
                .build();

        return dynamoDB;
    }


    public static void updateWithAddNewAttribute(AmazonDynamoDB amazonDynamoDB, String tableName) {

        DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
        Table table = dynamoDB.getTable("profile");

        Map<String, String> expressionAttributeNames = new HashMap<String, String>();
        expressionAttributeNames.put("#u1_1", "@type");

        String filterExpression = "attribute_exists (document.profile.responses.vertical.entries.marketingPreference)" +
                " AND attribute_not_exists (document.profile.responses.vertical.entries.marketingPreference.#u1_1)";

        ItemCollection<ScanOutcome> items =
                table.scan(filterExpression, // FilterExpression
                        "username,document", // ProjectionExpression
                        expressionAttributeNames,
                        null);

        Iterator<Item> iterator = items.iterator();
        Gson gson = new Gson();

        while (iterator.hasNext()) {

            UserProfile profile = gson.fromJson(iterator.next().getJSON("document"), UserProfile.class);
            System.out.println(profile);
            String username = profile.getUsername();
            System.out.println(username);

           // performUpdate(dynamoDB, username);

        }
    }

    private static void performUpdate(DynamoDB dynamoDB, String username) {
        try {

            Table table = dynamoDB.getTable("profile");

            UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("username", username)

                    .withUpdateExpression("").withNameMap(new NameMap().with("#type", "@type"))

                    .withValueMap(new ValueMap().withString(":value", "opt-inss")).withReturnValues(ReturnValue.ALL_NEW);

            UpdateItemOutcome outcome = table.updateItem(updateItemSpec);

            // Check the response.
            System.out.println("Printing item after adding new attribute...");
            System.out.println(outcome.getItem().toJSONPretty());

        } catch (Exception e) {
            //    System.err.println("Failed to add new attribute in " + tableName);
            System.err.println(e.getMessage());
        }
    }
}
