package com.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Profile {

    @JsonProperty("core")
    private Core core;
    @JsonProperty("responses")
    private Responses responses;

    @JsonProperty("core")
    public Core getCore() {
        return core;
    }

    @JsonProperty("core")
    public void setCore(Core core) {
        this.core = core;
    }

    @JsonProperty("responses")
    public Responses getResponses() {
        return responses;
    }

    @JsonProperty("responses")
    public void setResponses(Responses responses) {
        this.responses = responses;
    }

}