package com.entity;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "@type",
        "noContactViaEmail",
        "noContactViaPost",
        "noContactViaTelephone",
        "contactViaEmail"
})
public class MarketingPreference {


    @JsonProperty("noContactViaEmail")
    private Boolean noContactViaEmail;
    @JsonProperty("@type")
    private String type;
    @JsonProperty("noContactViaPost")
    private Boolean noContactViaPost;
    @JsonProperty("noContactViaTelephone")
    private Boolean noContactViaTelephone;

    @JsonProperty("contactViaEmail")
    private Boolean contactViaEmail;



    public Boolean getContactViaEmail() {
        return contactViaEmail;
    }

    public void setContactViaEmail(Boolean contactViaEmail) {
        this.contactViaEmail = contactViaEmail;
    }



    public Boolean getContactViaTelephone() {
        return contactViaTelephone;
    }

    public void setContactViaTelephone(Boolean contactViaTelephone) {
        this.contactViaTelephone = contactViaTelephone;
    }

    @JsonProperty("contactViaTelephone")
    private Boolean contactViaTelephone;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();


    @JsonProperty("noContactViaEmail")
    public Boolean getNoContactViaEmail() {
        return noContactViaEmail;
    }

    @JsonProperty("noContactViaEmail")
    public void setNoContactViaEmail(Boolean noContactViaEmail) {
        this.noContactViaEmail = noContactViaEmail;
    }

    @JsonProperty("@type")
    public String getType() {
        return type;
    }

    @JsonProperty("@type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("noContactViaPost")
    public Boolean getNoContactViaPost() {
        return noContactViaPost;
    }

    @JsonProperty("noContactViaPost")
    public void setNoContactViaPost(Boolean noContactViaPost) {
        this.noContactViaPost = noContactViaPost;
    }

    @JsonProperty("noContactViaTelephone")
    public Boolean getNoContactViaTelephone() {
        return noContactViaTelephone;
    }

    @JsonProperty("noContactViaTelephone")
    public void setNoContactViaTelephone(Boolean noContactViaTelephone) {
        this.noContactViaTelephone = noContactViaTelephone;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "@type is "+ this.type;
    }
}