package com.entity;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.amazonaws.services.dynamodbv2.document.internal.InternalUtils;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.Map;

public class ProfileMarshalls implements DynamoDBTypeConverter<Map<String, AttributeValue>, Map<String, Object>> {

    @Override
    public Map<String, AttributeValue> convert(Map<String, Object> object) {
        return InternalUtils.fromSimpleMap(object);
    }

    @Override
    public Map<String, Object> unconvert(Map<String, AttributeValue> object) {
        return InternalUtils.toSimpleMapValue(object);
    }

}