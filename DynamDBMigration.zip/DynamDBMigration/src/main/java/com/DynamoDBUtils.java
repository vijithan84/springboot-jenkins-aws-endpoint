package com;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.*;
import com.entity.UserProfile;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static com.AwsConfig.*;

public class DynamoDBUtils {

    public static AmazonDynamoDB getDynamoDB() {
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(AWS_ACCESS_KEY, AWS_SECRET_KEY);

        AmazonDynamoDB amazonDynamoDB = AmazonDynamoDBClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .withRegion(AWS_REGION)
                .build();

        return amazonDynamoDB;
    }

    static void getAllMarketingPreferences(AmazonDynamoDB amazonDynamoDB) {


        DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
        Table table = dynamoDB.getTable(TABLE_NAME);
        DynamoDBMapper mapper = new DynamoDBMapper(amazonDynamoDB);

        Map<String, Object> expressionAttributeValues = new HashMap();
        expressionAttributeValues.put(":opt", "c8dde904-f1dc-438c-8046-4633baf5797f");
    //    expressionAttributeValues.put(":true", true);


        //97b05290-8198-4614-bcb0-fb008c89be5f
        //"profile.responses.vertical.entries[0].marketingPreference.@type = :false OR profile.responses.vertical.entries[0].marketingPreference.noContactViaEmail = :true " +
        //                        "OR profile.responses.vertical.entries[0].marketingPreference.contactViaEmail = :false OR profile.responses.vertical.entries[0].marketingPreference.contactViaEmail = :true", // FilterExpression
        //                "username, profile.core.country, profile.responses.vertical.entries"

        Map<String, String> expressionAttributeNames = new HashMap<String,String>();
//        expressionAttributeNames.put("#u1_1", "profile");
//        expressionAttributeNames.put("#u1_2", "responses");
//        expressionAttributeNames.put("#u1_3", "vertical");
//        expressionAttributeNames.put("#u1_4", "entries[0]");
//        expressionAttributeNames.put("#u1_5", "marketingPreference");
        expressionAttributeNames.put("#u1_6", "lastUpdated");


//        "profile.responses.vertical.entries[0].marketingPreference.noContactViaEmail = :false OR profile.responses.vertical.entries[0].marketingPreference.noContactViaEmail = :true" +
//                " OR profile.responses.vertical.entries[0].marketingPreference.contactViaEmail = :false OR profile.responses.vertical.entries[0].marketingPreference.contactViaEmail = :true",
//                "username, profile.core.country, profile.responses.vertical.entries"
//
        String filterExpression = "#u1_6";

        ItemCollection<ScanOutcome> items = table.scan( "username = :opt","profile", // ProjectionExpression
                null, // ExpressionAttributeNames - not used in this example
                expressionAttributeValues);

        Iterator<Item> iterator = items.iterator();
        Gson gson = new Gson();
        System.out.println(iterator.next().getJSONPretty("profile"));

        while (iterator.hasNext()) {

            UserProfile profile = gson.fromJson(iterator.next().toJSON(), UserProfile.class);

                   System.out.println(profile.getUsername());

        //    updateProfile(amazonDynamoDB, profile);

        }
    }

    private static void updateProfile(AmazonDynamoDB dynamoDB, UserProfile profile) {
        System.out.print(profile.getUsername());
        System.out.println(" | " + profile.getProfile().getCore().getForename());
        String country = profile.getProfile().getCore().getCountry();

    }
}
