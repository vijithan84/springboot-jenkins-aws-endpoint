package com;

public class TestProfileData {

    public static String firstUser = "{\n" +
            "  \"lastUpdated\": \"2018-07-12T07:30:59.697\",\n" +
            "  \"profile\": {\n" +
            "    \"core\": {\n" +
            "      \"acceptTerms\": true,\n" +
            "      \"addressLine1\": \"10 South Nobel Lane\",\n" +
            "      \"addressLine2\": \"16 West Nobel Freeway\",\n" +
            "      \"city\": \"WCanBlj\",\n" +
            "      \"companyName\": \"Stout and Boone Traders\",\n" +
            "      \"companySize\": \"NO_2500\",\n" +
            "      \"country\": \"AE\",\n" +
            "      \"email\": \"perifowo@mailinator.com\",\n" +
            "      \"forename\": \"Ingrid\",\n" +
            "      \"id\": \"6189877f-3578-4cb5-b511-95fe8cb2a680\",\n" +
            "      \"industry\": \"CONSULTING\",\n" +
            "      \"jobFunction\": \"CFO\",\n" +
            "      \"jobTitle\": \"GydutO\",\n" +
            "      \"marketingPreferences\": null,\n" +
            "      \"otherJobFunction\": null,\n" +
            "      \"phoneNumber\": \"+919-34-2575109\",\n" +
            "      \"photo\": null,\n" +
            "      \"postcode\": \"94975\",\n" +
            "      \"state\": null,\n" +
            "      \"surname\": \"Newman\"\n" +
            "    },\n" +
            "    \"responses\": {\n" +
            "      \"content\": {\n" +
            "        \"entries\": [\n" +
            "          {\n" +
            "            \"dateTime\": \"2018-07-12T07:16:41.217\",\n" +
            "            \"priorityCode\": \"Null\",\n" +
            "            \"responseType\": \"C_asd\"\n" +
            "          }\n" +
            "        ]\n" +
            "      },\n" +
            "      \"vertical\": {\n" +
            "        \"entries\": [\n" +
            "          {\n" +
            "            \"dateTime\": \"2018-07-12T07:30:58.309\",\n" +
            "            \"marketingPreference\": {\n" +
            "              \"@type\": \"opt-in\",\n" +
            "              \"noContactViaEmail\": true,\n" +
            "              \"noContactViaPost\": false,\n" +
            "              \"noContactViaTelephone\": false,\n" +
            "              \"signupSource\": {\n" +
            "                \"id\": \"C_asd\",\n" +
            "                \"sourceType\": \"COMMUNITY\"\n" +
            "              }\n" +
            "            },\n" +
            "            \"responseType\": \"FINANCE\"\n" +
            "          }\n" +
            "        ]\n" +
            "      }\n" +
            "    }\n" +
            "  },\n" +
            "  \"username\": \"583922cd-55c0-450b-8c0a-f2bbbf309d6d\"\n" +
            "}"
            ;
    public static String secondUser = "{\n"+
            "  \"lastUpdated\": \"2018-10-03T07:53:39.597\",\n"+
            "  \"profile\": {\n"+
            "    \"core\": {\n"+
            "      \"acceptTerms\": true,\n"+
            "      \"addressLine1\": null,\n"+
            "      \"addressLine2\": null,\n"+
            "      \"city\": null,\n"+
            "      \"companyName\": \"Jeremy Medina\",\n"+
            "      \"companySize\": null,\n"+
            "      \"country\": \"IN\",\n"+
            "      \"email\": \"0egy0@dim-coin.com\",\n"+
            "      \"forename\": \"Billy Chandler\",\n"+
            "      \"id\": \"3e94139e-fe56-4269-9277-13fa33ba13ba\",\n"+
            "      \"industry\": null,\n"+
            "      \"jobFunction\": null,\n"+
            "      \"jobTitle\": \"siv\",\n"+
            "      \"marketingPreferences\": {\n"+
            "        \"@type\": \"opt-out\",\n"+
            "        \"noContactViaEmail\": false,\n"+
            "        \"noContactViaPost\": false,\n"+
            "        \"noContactViaTelephone\": false,\n"+
            "        \"noThirdPartyMarketing\": true,\n"+
            "        \"signupSource\": null\n"+
            "      },\n"+
            "      \"otherJobFunction\": null,\n"+
            "      \"phoneNumber\": null,\n"+
            "      \"photo\": null,\n"+
            "      \"postcode\": null,\n"+
            "      \"state\": null,\n"+
            "      \"surname\": \"Holloway\"\n"+
            "    },\n"+
            "    \"responses\": {\n"+
            "      \"agenda\": {},\n"+
            "      \"content\": {},\n"+
            "      \"sponsor\": {},\n"+
            "      \"vertical\": {\n"+
            "        \"entries\": [\n"+
            "          {\n"+
            "            \"dateTime\": \"2018-10-03T08:31:19.421\",\n"+
            "            \"marketingPreference\": {\n"+
            "              \"@type\": \"opt-out\",\n"+
            "              \"noContactViaEmail\": true,\n"+
            "              \"noContactViaPost\": false,\n"+
            "              \"noContactViaTelephone\": false,\n"+
            "              \"signupSource\": {\n"+
            "                \"id\": \"CQ425482_I09_GB214_01\",\n"+
            "                \"sourceType\": \"COMMUNITY\"\n"+
            "              }\n"+
            "            },\n"+
            "            \"responseType\": \"LIFESCIENCE\"\n"+
            "          }\n"+
            "        ]\n"+
            "      }\n"+
            "    }\n"+
            "  },\n"+
            "  \"username\": \"c8dde904-f1dc-438c-8046-4633baf5797f\"\n"+
            "}";
    public static String thirdUser = "{\n" +
            "  \"lastUpdated\": \"2018-09-03T08:22:27.665\",\n" +
            "  \"profile\": {\n" +
            "    \"core\": {\n" +
            "      \"acceptTerms\": true,\n"+
            "      \"addressLine1\": null,\n"+
            "      \"addressLine2\": null,\n"+
            "      \"city\": null,\n"+
            "      \"companyName\": \"Jeremy Medina\",\n"+
            "      \"companySize\": null,\n"+
            "      \"country\": \"IN\",\n"+
            "      \"email\": \"0egy0@dim-coin.com\",\n"+
            "      \"forename\": \"Billy Chandler\",\n"+
            "      \"id\": \"3e94139e-fe56-4269-9277-13fa33ba13ba\",\n"+
            "      \"industry\": null,\n"+
            "      \"jobFunction\": null,\n"+
            "      \"jobTitle\": \"siv\",\n"+
            "      \"marketingPreferences\": {\n"+
            "        \"@type\": \"opt-out\",\n"+
            "        \"noContactViaEmail\": false,\n"+
            "        \"noContactViaPost\": false,\n"+
            "        \"noContactViaTelephone\": false,\n"+
            "        \"noThirdPartyMarketing\": true,\n"+
            "        \"signupSource\": null\n"+
            "      },\n"+
            "      \"otherJobFunction\": null,\n"+
            "      \"phoneNumber\": null,\n"+
            "      \"photo\": null,\n"+
            "      \"postcode\": null,\n"+
            "      \"state\": null,\n"+
            "      \"surname\": \"Holloway\"\n"+
            "    },\n"+
            "    \"responses\": {\n" +
            "      \"agenda\": {},\n" +
            "      \"content\": {},\n" +
            "      \"sponsor\": {},\n" +
            "      \"vertical\": {\n" +
            "        \"entries\": [\n" +
            "          {\n" +
            "            \"dateTime\": \"2018-07-12T07:30:58.309\",\n" +
            "            \"marketingPreference\": {\n" +
            "              \"noContactViaEmail\": true,\n" +
            "              \"noContactViaPost\": false,\n" +
            "              \"noContactViaTelephone\": false,\n" +
            "              \"signupSource\": {\n" +
            "                \"id\": \"C_asd\",\n" +
            "                \"sourceType\": \"COMMUNITY\"\n" +
            "              }\n" +
            "            },\n" +
            "            \"responseType\": \"FINANCE\"\n" +
            "          },\n" +
            "          {\n" +
            "            \"dateTime\": \"2018-07-12T07:30:58.309\",\n" +
            "            \"marketingPreference\": {\n" +
            "              \"noContactViaEmail\": true,\n" +
            "              \"noContactViaPost\": false,\n" +
            "              \"noContactViaTelephone\": false,\n" +
            "              \"signupSource\": {\n" +
            "                \"id\": \"C_asd\",\n" +
            "                \"sourceType\": \"COMMUNITY\"\n" +
            "              }\n" +
            "            },\n" +
            "            \"responseType\": \"LIFESCIENCES\"\n" +
            "          }\n" +
            "        ]\n" +
            "      }\n" +
            "    }\n" +
            "  },\n" +
            "  \"username\": \"ce4467f6-6c9d-4ee6-913d-c02c8e47d925\"\n" +
            "}";
}