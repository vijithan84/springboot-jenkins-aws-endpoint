package com;

import com.amazonaws.services.dynamodbv2.document.*;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.*;
import com.entity.Entries;
import com.entity.MarketingPreference;
import com.entity.UserProfile;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import javafx.scene.control.Tab;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class DynamoDBMigrationTest {

    private static DynamoDBMapper dynamoDBMapper;
    private static AmazonDynamoDB amazonDynamoDB;

    @BeforeClass
    public static void setupClass() {

        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(
                "amazonAWSAccessKey", "amazonAWSSecretKey");

        amazonDynamoDB = AmazonDynamoDBClientBuilder.standard().withEndpointConfiguration(
                new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "us-west-2"))
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .build();
    }

    @Before
    public void setup() {
        try {

            dynamoDBMapper = new DynamoDBMapper(amazonDynamoDB);

            CreateTableRequest tableRequest = dynamoDBMapper.generateCreateTableRequest(UserProfile.class);

            tableRequest.setProvisionedThroughput(new ProvisionedThroughput(1L, 1L));

            amazonDynamoDB.createTable(tableRequest);

        } catch (ResourceInUseException e) {
            System.out.println("Do nothing, table already created");
        } finally {
            insertUserDetails();
        }
    }

    private void insertUserDetails() {
        DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
        Table table = dynamoDB.getTable("profile");

        Item firstUser =
                new Item()
                        .withPrimaryKey("username", "583922cd-55c0-450b-8c0a-f2bbbf309d6d")
                        .withJSON("document", TestProfileData.firstUser);

        Item secondUser =
                new Item()
                        .withPrimaryKey("username", "c8dde904-f1dc-438c-8046-4633baf5797f")
                        .withJSON("document", TestProfileData.secondUser);

        Item thirdUser =
                new Item()
                        .withPrimaryKey("username", "ce4467f6-6c9d-4ee6-913d-c02c8e47d925")
                        .withJSON("document", TestProfileData.thirdUser);
        try {
            table.putItem(firstUser);
            table.putItem(secondUser);
            table.putItem(thirdUser);

        } catch (Exception e) {
        }

    }

    @Test
    public void getUserProfileTest() {
        JsonParser parser = new JsonParser();

        DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
        Table table = dynamoDB.getTable("profile");

        Item documentItem =
                table.getItem(new GetItemSpec()
                        .withPrimaryKey("username", "ce4467f6-6c9d-4ee6-913d-c02c8e47d925")
                        .withAttributesToGet("document"));

        System.out.println(documentItem.getJSONPretty("document"));
        JsonElement actual = parser.parse(documentItem.getJSONPretty("document"));
        JsonElement expected = parser.parse(TestProfileData.thirdUser);
        assertEquals(actual, expected);
    }


    @Test
    public void findMissingTypeProfileTest() {

        DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
        Table table = dynamoDB.getTable("profile");
        String username;

        // DynamoDBUtils.getAllMarketingPreferences(amazonDynamoDB);

        Map<String, Object> expressionAttributeValues = new HashMap<String, Object>();
        expressionAttributeValues.put(":pr", "");

        Map<String, String> expressionAttributeNames = new HashMap<String, String>();
        expressionAttributeNames.put("#u1_1", "@type");

        String projectionExpression = "attribute_exists (document.profile.responses.vertical.entries.marketingPreference)" +
                " AND attribute_not_exists (document.profile.responses.vertical.entries.marketingPreference.#u1_1)";

        ItemCollection<ScanOutcome> items =
                table.scan(projectionExpression, // FilterExpression
                        "username,document", // ProjectionExpression
                        expressionAttributeNames,
                        null // ExpressionAttributeNames - not used in this example
                        //expressionAttributeValues
                );



        Iterator<Item> iterator = items.iterator();
        Gson gson = new Gson();

        while (iterator.hasNext()) {

            UserProfile profile = gson.fromJson(iterator.next().getJSON("document"), UserProfile.class);

            System.out.println(profile.getUsername());


       }
    }
   /* private static void updateWithAddNewAttribute(UserProfile profile) {
        DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);

        Table table = dynamoDB.getTable("profile");

        String updateExpression = "set #type = :value";
        try {

            UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("username", username)
                    .withUpdateExpression("").withNameMap(new NameMap().with("#type", "@type"))
                    .withValueMap(new ValueMap().withString(":value", "")).withReturnValues(ReturnValue.ALL_NEW);

            UpdateItemOutcome outcome = table.updateItem(updateItemSpec);

            // Check the response.
            System.out.println("Printing item after adding new attribute...");
            System.out.println(outcome.getItem().toJSONPretty());

        }
        catch (Exception e) {
        //    System.err.println("Failed to add new attribute in " + tableName);
            System.err.println(e.getMessage());
        }
    }*/
}
